// CS370 - Fall 2014
// Assign03 - Limelight

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "materials.h"
#include "lighting.h"
#include "vectorops.h"

// Shader file utility functions
#include "shaderutils.h"

// Shader files
GLchar* lightVertexFile = "stagevert.vs";
GLchar* lightFragmentFile = "stagefrag.fs";
GLchar* defaultVertexFile = "basicvert.vs";
GLchar* defaultFragmentFile = "basicfrag.fs";

// Shader objects
GLuint lightShaderProg;
GLuint defaultShaderProg;
GLuint num_lights_param;
GLint num_lights = 1;

#define LIGHT_OFF 0
#define LIGHT_ON 1
#define LIGHT_1 0
#define LIGHT_2 1
#define LIGHT_3 2
#define NUM_LIGHTS 3
#define DEG_TO_RAD 0.0175f
#define NO_STRIPS 30
#define WHITE 0
#define RED 1
#define GREEN 2
#define BLUE 3
#define X 0
#define Y 1
#define Z 2
#define N 8
#define STAGE 1

// Global variables
GLenum lights[4] = { GL_LIGHT0, GL_LIGHT1, GL_LIGHT2, GL_LIGHT3 };

// Shadow matrices
GLfloat M1_s[16];
GLfloat M2_s[16];
GLfloat M3_s[16];

// Global animation variables
GLint time = 0;
GLint lasttime = 0;
GLint fps = 30;

void display();
void render_Scene(bool shadow);
void quad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[]);
void reshape(int w, int h);
void keyfunc(unsigned char key, int x, int y);
void idlefunc();

int main(int argc, char* argv[])
{
	// Initialize glut
    glutInit(&argc, argv);

	// Initialize window
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    glutCreateWindow("Limelight");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// Define callbacks
    glutReshapeFunc(reshape);
    glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutIdleFunc(idlefunc);

	// Set background color to grey
	glClearColor(0.6f, 0.6f, 0.6f, 1.0f);

	// Set shading model
	glShadeModel(GL_SMOOTH);

	// Enable depth test
    glEnable(GL_DEPTH_TEST);

	// Load shader programs
	defaultShaderProg = load_shaders(defaultVertexFile,defaultFragmentFile);

	// Activate shader program
	glUseProgram(defaultShaderProg);

	// Start graphics loop
	glutMainLoop();
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
    // Set modelview matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// Set viewpoint
	glRotatef(-45.0,0.0,1.0,0.0);
	glRotatef(36.25,1.0,0.0,0.0);

	// Render scene without shadows
	render_Scene(false);

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

void render_Scene(bool shadow)
{
	// Placeholder stage object
	glPushMatrix();
		glColor3f(1.0f, 1.0f, 0.0f);
		glScalef(8.0, 1.0, 4.0);
		glutSolidCube(2.0);
	glPopMatrix();
}

// Reshape callback
void reshape(int w, int h)
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    if (w <= h)
        glOrtho(-10.0, 10.0, -10.0 * (GLfloat) h / (GLfloat) w,
            10.0 * (GLfloat) h / (GLfloat) w, -10.0, 10.0);
    else
        glOrtho(-10.0 * (GLfloat) w / (GLfloat) h,
            10.0 * (GLfloat) w / (GLfloat) h, -10.0, 10.0, -10.0, 10.0);
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// Keypress functionality

	// Esc to quit
	if (key==27)
	{
		exit(0);
	}

	glutPostRedisplay();

}

// Idle callback
void idlefunc()
{
	// Time-based Animations

}


// Routine to draw polygon face
void quad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[])
{
	// Draw face
	glBegin(GL_POLYGON);
		glVertex3fv(v1);
		glVertex3fv(v2);
		glVertex3fv(v3);
		glVertex3fv(v4);
	glEnd();
}
