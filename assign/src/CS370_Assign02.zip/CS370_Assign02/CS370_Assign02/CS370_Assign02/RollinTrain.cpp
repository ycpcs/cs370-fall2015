// CS370 - Fall 2014
// Assign02 - Rollin Train

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

// Shader file utility functions
#include "shaderutils.h"
#include "train.h"

// Shader files
GLchar* vertexFile = "basicvert.vs";
GLchar* fragmentFile = "basicfrag.fs";

// Shader objects
GLuint shaderProg;

#define RAD2DEG (180.0f/3.14159f)
#define DEG2RAD (3.14159f/180.0f)

// View modes
#define ORTHOGRAPHIC 0
#define PERSPECTIVE 1

// Component indices
#define X 0
#define Y 1
#define Z 2

// Display list identifiers
#define BLOCKS 1

// Define globals
GLfloat eye[3] = { 2.0f, 2.0f, 2.0f };
GLfloat at[3] = { 0.0f, 0.0f, 0.0f };
GLfloat up[3] = { 0.0f, 1.0f, 0.0f };

// Function Prototypes
void block_list();
void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void reshape(int w, int h);
void idlefunc();

int main(int argc, char* argv[])
{
	// Initialize glut
	glutInit(&argc, argv);

	// Initialize window
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(500,500);
	glutCreateWindow("RailRoad");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// Define callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutIdleFunc(idlefunc);
	glutReshapeFunc(reshape);

	// Initialization
	// Set background color
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Load shader programs
	shaderProg = load_shaders(vertexFile,fragmentFile);

	// Activate shader program
	glUseProgram(shaderProg);

	// Create display lists
	block_list();

	// Start graphics loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-15.0, 15.0, -15.0, 15.0, -15.0, 15.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(eye[X], eye[Y], eye[Z], at[X], at[Y], at[Z], up[X], up[Y], up[Z]);

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// Draw blocks
	glCallList(BLOCKS);
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// Quit program
	if (key==27)
	{
		exit(0);
	}

}

// Reshape callback
void reshape(int w, int h)
{
	GLfloat ratio;

	// Set new screen extents
	glViewport(0,0,w,h);
}

// Idle callback
void idlefunc()
{

}

// Routine to create block list
void block_list()
{
	glNewList(BLOCKS, GL_COMPILE);
	glPushAttrib(GL_CURRENT_BIT);

	glPushMatrix();
		// Offset for rails
		glTranslatef(0.0, RAIL_HEIGHT, -(RAIL_LENGTH / 2.0) - (BOTTOM_BLOCK_SIZE / 2.0));
		// Bottom block
		glTranslatef(0.0, BOTTOM_BLOCK_SIZE / 2.0, 0.0);
		glColor3f(1.0, 0.0, 1.0);
		glutSolidCube(BOTTOM_BLOCK_SIZE);

		// Middle block
		glTranslatef(0.0, BOTTOM_BLOCK_SIZE / 2.0 + MIDDLE_BLOCK_SIZE / 2.0, 0.0);
		glColor3f(0.0, 1.0, 1.0);
		glutSolidCube(MIDDLE_BLOCK_SIZE);

		// Top block
		glTranslatef(0.0, MIDDLE_BLOCK_SIZE / 2.0 + TOP_BLOCK_SIZE / 2.0, 0.0);
		glColor3f(0.5, 0.5, 1.0);
		glutSolidCube(TOP_BLOCK_SIZE);

	glPopMatrix();

	glPopAttrib();
	glEndList();
}
