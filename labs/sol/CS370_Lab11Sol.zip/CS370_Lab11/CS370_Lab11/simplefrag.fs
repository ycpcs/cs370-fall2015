// TODO: Define globals
varying vec4 color_out;

void main()
{
    // TODO: Set fragment color
    gl_FragColor = color_out;
}
