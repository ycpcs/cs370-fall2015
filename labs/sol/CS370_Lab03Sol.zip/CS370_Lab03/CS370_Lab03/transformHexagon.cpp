// CS370 - Fall 2014
// Lab03 - TransformHexagon

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glut.h>
#endif

// Since we are using 2D for now
#define DIM 2

// Original hexagon vertices
GLfloat u1[2] = {0.5f,0.866f};
GLfloat u2[2] = {-0.5f,0.866f};
GLfloat u3[2] = {-1.0f,0.0f};
GLfloat u4[2] = {-0.5f,-0.866f};
GLfloat u5[2] = {0.5f,-0.866f};
GLfloat u6[2] = {1.0f,0.0f};

// Transformed vertices
GLfloat v1[2],v2[2],v3[2],v4[2],v5[2],v6[2];

// Transformation matrix
GLfloat M[2][2] = {{0.707f,-0.707f},{0.707f,0.707f}};

void display();
void render_Scene();
void Trans2D(GLfloat M[][DIM], GLfloat u[], GLfloat v[]);

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);

	// Set the window size to 500x500 pixels
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Transformed Hexagon");

	// Define callbacks
	glutDisplayFunc(display);

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT);

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// TODO: Draw red hexagon with u vertices
	// Set current color to red
	glColor3f(1.0f, 0.0f, 0.0f);

	// Draw red hexagon (original)
	glBegin(GL_POLYGON);
		glVertex2fv(u1);
		glVertex2fv(u2);
		glVertex2fv(u3);
		glVertex2fv(u4);
		glVertex2fv(u5);
		glVertex2fv(u6);
	glEnd();

	// TODO: Transform u vertices to v vertices
	// Transform vertices
	Trans2D(M, u1, v1);
	Trans2D(M, u2, v2);
	Trans2D(M, u3, v3);
	Trans2D(M, u4, v4);
	Trans2D(M, u5, v5);
	Trans2D(M, u6, v6);

	// TODO: Draw green hexagon with v vertices
	// Set current color to green
	// Draw green hexagon (transformed)
	glColor3f(0.0f, 1.0f, 0.0f);
	glBegin(GL_POLYGON);
		glVertex2fv(v1);
		glVertex2fv(v2);
		glVertex2fv(v3);
		glVertex2fv(v4);
		glVertex2fv(v5);
		glVertex2fv(v6);
	glEnd();

}

// Function to compute transformation
void Trans2D(GLfloat M[][DIM], GLfloat u[], GLfloat v[])
{
	// Compute matrix-vector product
	for (int i=0; i<DIM; i++)
	{
		v[i] = 0.0f;
		for (int j=0; j<DIM; j++)
		{
			v[i] += M[i][j]*u[j];
		}
	}

	return;
}