// CS370 - Fall 2014
// Lab04 - RSHexagon

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glut.h>
#endif

// Original hexagon vertices
GLfloat u1[2] = {0.5f,0.866f};
GLfloat u2[2] = {-0.5f,0.866f};
GLfloat u3[2] = {-1.0f,0.0f};
GLfloat u4[2] = {-0.5f,-0.866f};
GLfloat u5[2] = {0.5f,-0.866f};
GLfloat u6[2] = {1.0f,0.0f};

/*
// Original hexagon vertices offset
GLfloat u1[2] = {0.6f,0.966f};
GLfloat u2[2] = {-0.4f,0.966f};
GLfloat u3[2] = {-0.9f,0.1f};
GLfloat u4[2] = {-0.4f,-0.766f};
GLfloat u5[2] = {0.6f,-0.766f};
GLfloat u6[2] = {1.1f,0.1f};
*/

/*
// TODO: Compute Scaled vertices
GLfloat v1[2] = { 0.25f, 0.6495f };
GLfloat v2[2] = { -0.25f, 0.6495f };
GLfloat v3[2] = { -0.5f, 0.0f };
GLfloat v4[2] = { -0.25f, -0.6495f };
GLfloat v5[2] = { 0.25f, -0.6495f };
GLfloat v6[2] = { 0.5f, 0.0f };
*/

// TODO: Scaled/Rotated vertices
GLfloat v1[2] = {-0.4375f,0.5412f};
GLfloat v2[2] = {-0.6875f,0.1082f};
GLfloat v3[2] = {-0.25f,-0.433f};
GLfloat v4[2] = {0.4375f,-0.5412f};
GLfloat v5[2] = {0.6875f,-0.1082f};
GLfloat v6[2] = {0.25f,0.433f};

void display();
void render_Scene();

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);

	// Set the window size to 500x500 pixels
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Scaled/Rotated Hexagon");

	// Define callbacks
	glutDisplayFunc(display);

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT);

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// TODO: Draw green computed hexagon vertices
	glColor3f(0.0f,1.0f,0.0f);
	glBegin(GL_POLYGON);
		glVertex2fv(v1);
		glVertex2fv(v2);
		glVertex2fv(v3);
		glVertex2fv(v4);
		glVertex2fv(v5);
		glVertex2fv(v6);
	glEnd();

	// Set transformations
	// TODO: Rotate 60 degrees about z-axis
	glRotatef(60.0f, 0.0f, 0.0f, 1.0f);

	// TODO: Scale .5 in x, .75 in y (note preserve z)
	glScalef(0.5f, 0.75f, 1.0f);

	// TODO: Draw red hexagon (transformed)
	glColor3f(1.0f,0.0f,0.0f);
	glBegin(GL_POLYGON);
		glVertex2fv(u1);
		glVertex2fv(u2);
		glVertex2fv(u3);
		glVertex2fv(u4);
		glVertex2fv(u5);
		glVertex2fv(u6);
	glEnd();

}
