// CS370 - Fall 2014
// Lab13 - vertexNormalCube

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "lighting.h"
#include "materials.h"

// Shader file utility functions
#include "shaderutils.h"

// Shader files
GLchar* vertexFile = "lightvert.vs";
GLchar* fragmentFile = "lightfrag.fs";

// Shader objects
GLuint shaderProg;
GLuint num_lights_param;

// Time based rendering parameters
#define DEG_PER_SEC (360.0f/60.0f)
#define FPS_INTERVAL 1000
GLint fps = 30;
GLfloat rpm = 10.0f;
GLint time = 0;
GLint lasttime = 0;

#define BRASS 1
#define CUBE 1

// Cube vertices
GLfloat cube[][3] = {{-1.0f,-1.0f,-1.0f},{1.0f,-1.0f,-1.0f},{1.0f,-1.0f,1.0f},
                     {-1.0f,-1.0f,1.0f},{-1.0f,1.0f,-1.0f},{1.0f,1.0f,-1.0f},
                     {1.0f,1.0f,1.0f},{-1.0f,1.0f,1.0f}};

// TODO: Cube vertex normals
GLfloat vnormals[][3] = { { -1.0f, -1.0f, -1.0f }, { 1.0f, -1.0f, -1.0f }, { 1.0f, -1.0f, 1.0f },
						  { -1.0f, -1.0f, 1.0f }, { -1.0f, 1.0f, -1.0f }, { 1.0f, 1.0f, -1.0f },
						  { 1.0f, 1.0f, 1.0f }, { -1.0f, 1.0f, 1.0f } };

// TODO: Light0 (point) Parameters
GLfloat light0_pos[] = { 4.0f, 0.0f, 0.0f, 1.0f };

// TODO: Light1 (spot) Parameters
GLfloat light1_pos[] = { 0.0f, 2.0f, 0.0f, 1.0f };
GLfloat light1_dir[] = { 0.0f, -1.0f, 0.0f };
GLfloat light1_cutoff = 90.0f;
GLfloat light1_exp = 0.0f;

bool anim = false;
GLint num_lights = 2;
bool spot_flag = true;

// Global rotation angle
GLfloat theta = 0.0f;

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void idlefunc();
void reshape(int w, int h);
void colorcube();
void vquad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[], 
		   GLfloat n1[], GLfloat n2[], GLfloat n3[], GLfloat n4[]);
void create_lists();

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	// Set the window size to 500x500 pixels
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Vertex Normal Cube");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// Define callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutIdleFunc(idlefunc);
	glutReshapeFunc(reshape);

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// Set initial material
	set_material(GL_FRONT_AND_BACK, &brass);

	// Create display list
	create_lists();

	// Load shader programs
	shaderProg = load_shaders(vertexFile,fragmentFile);

	// Activate shader program
	glUseProgram(shaderProg);

	// Associate num_lights parameter
	num_lights_param = glGetUniformLocation(shaderProg,"num_lights");

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Set number of lights
	glUniform1i(num_lights_param,num_lights);

	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set modelview matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// Set global lights
	// TODO: Set point light source fixed in world
	set_PointLight(GL_LIGHT0, &white_light, light0_pos);

	// TODO: Set spot light source fixed in world
	set_SpotLight(GL_LIGHT1, &red_light, light1_pos, light1_dir, light1_cutoff, light1_exp);

	// Render cube using display list
	glPushMatrix();
	glRotatef(45.0f,1.0f,0.0f,0.0f);
	glRotatef(theta,0.0f,1.0f,0.0f);
	glCallList(CUBE);
	glPopMatrix();
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// l toggles red light
	if (key == 'l')
	{
		if (spot_flag)
		{
			num_lights = 1;
			spot_flag = false;
		}
		else
		{
			num_lights = 2;
			spot_flag = true;
		}
	}

	// <space> toggles animation
	if (key == ' ')
	{
		if (!anim)
		{
			lasttime = glutGet(GLUT_ELAPSED_TIME);
		}
		anim = !anim;
	}

	// <esc> quits
	if (key == 27)
	{
		exit(0);
	}

	// Redraw screen
	glutPostRedisplay();
}

// Idle callback
void idlefunc()
{
	if (anim)
	{
		// Get total elapsed time
		time = glutGet(GLUT_ELAPSED_TIME);

		// Update if past desired interval
		if (time-lasttime > 1000.0f/fps)
		{
			// Compute angular change for desired rpm
			theta += 6.0f*rpm*(time-lasttime)/1000.0f;
		
			// Completed full revolution
			if (theta > 360.0f)
			{
				theta -= 360.0f;
			}

			// Update lasttime (reset timer)
			lasttime = time;

			// Render scene
			glutPostRedisplay();
		}
	}
}

// Reshape callback
void reshape(int w, int h)
{
	GLfloat ratio;

	// Set new screen extents
	glViewport(0,0,w,h);

	// Set projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	// Taller than wide so scale height
	if (w <= h)
	{
		ratio = (GLfloat) h / (GLfloat) w;
		glOrtho(-2.0f,2.0f,-2.0f*ratio,2.0f*ratio,-2.0f,2.0f);
	}
	// Wider than tall so scale width
	else
	{
		ratio = (GLfloat) w / (GLfloat) h;
		glOrtho(-2.0f*ratio,2.0*ratio,-2.0f,2.0f,-2.0f,2.0f);
	}
}

// Routine to draw cube
void colorcube()
{
	// Top face
	vquad(cube[4],cube[7],cube[6],cube[5],vnormals[4],vnormals[7],vnormals[6],vnormals[5]);

	// Bottom face
	vquad(cube[0],cube[1],cube[2],cube[3],vnormals[0],vnormals[1],vnormals[2],vnormals[3]);

	// Left face
	vquad(cube[0],cube[3],cube[7],cube[4],vnormals[0],vnormals[3],vnormals[7],vnormals[4]);

	// Right face
	vquad(cube[1],cube[5],cube[6],cube[2],vnormals[1],vnormals[5],vnormals[6],vnormals[2]);

	// Front face
	vquad(cube[2],cube[6],cube[7],cube[3],vnormals[2],vnormals[6],vnormals[7],vnormals[3]);

	// Back face
	vquad(cube[0],cube[4],cube[5],cube[1],vnormals[0],vnormals[4],vnormals[5],vnormals[1]);
}

// Routine to draw (outlined) quadrilateral face
void vquad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[], GLfloat n1[], GLfloat n2[], GLfloat n3[], GLfloat n4[])
{

	// TODO: Draw face with per vertex normals
	glBegin(GL_POLYGON);
		glNormal3fv(n1);
		glVertex3fv(v1);
		glNormal3fv(n2);
		glVertex3fv(v2);
		glNormal3fv(n3);
		glVertex3fv(v3);
		glNormal3fv(n4);
		glVertex3fv(v4);
	glEnd();
}

// Routine to create display lists
void create_lists()
{
	// Create colorcube display list
	glNewList(CUBE, GL_COMPILE);
		glPushAttrib(GL_CURRENT_BIT);
		colorcube();
		glPopAttrib();
	glEndList();
}
