// CS370 - Fall 2014
// Lab14 - RecursiveCube

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "lighting.h"
#include "materials.h"
#include "vectorops.h"

// Shader file utility functions
#include "shaderutils.h"

// Shader files
GLchar* vertexFile = "lightvert.vs";
GLchar* fragmentFile = "lightfrag.fs";

// Shader objects
GLuint shaderProg;
GLuint num_lights_param;

#define BRASS 1
#define RED_PLASTIC 2
#define CUBE 1
#define SURFACE 0
#define VERTEX 1

bool anim = false;

// Cube vertices
GLfloat cube[][3] = {{-1.0f,-1.0f,-1.0f},{1.0f,-1.0f,-1.0f},{1.0f,-1.0f,1.0f},
                     {-1.0f,-1.0f,1.0f},{-1.0f,1.0f,-1.0f},{1.0f,1.0f,-1.0f},
                     {1.0f,1.0f,1.0f},{-1.0f,1.0f,1.0f}};

// Normal vertices
GLfloat vnorm[][3] = { { -1.0f, -1.0f, -1.0f }, { 1.0f, -1.0f, -1.0f }, { 1.0f, -1.0f, 1.0f },
				   { -1.0f, -1.0f, 1.0f }, { -1.0f, 1.0f, -1.0f }, { 1.0f, 1.0f, -1.0f },
				   { 1.0f, 1.0f, 1.0f }, { -1.0f, 1.0f, 1.0f } };


// Light0 (directional) Parameters
GLfloat light0_pos[] = {0.0f,0.0f,2.0f,1.0f};
GLfloat light0_dir[] = {0.0f,0.0f,-1.0f};
GLfloat light0_cutoff = 180.0f;
GLfloat light0_exp = 0.0f;

// Light1 (spot) Parameters
GLfloat light1_pos[] = {0.0f,3.0f,0.0f,1.0f};
GLfloat light1_dir[] = {0.0f,-1.0f,0.0f};
GLfloat light1_cutoff = 40.0f;
GLfloat light1_exp = 0.0f;

// Global light variables
GLint num_lights = 2;

// Global rotation angle
GLfloat theta = 0.0f;
GLfloat dtheta = 0.1f;

// Global subdivision parameters
int div_level = 3;
int normal_mode = SURFACE;

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void idlefunc();
void reshape(int w, int h);
void main_menu(int id);
void colorcube();
void rquad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[], GLfloat n1[], GLfloat n2[], GLfloat n3[], GLfloat n4[]);
void div_quad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[], GLfloat n1[], GLfloat n2[], GLfloat n3[], GLfloat n4[], int n);

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	// Set the window size to 500x500 pixels
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Recursive Cube");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// Define callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutIdleFunc(idlefunc);
	glutReshapeFunc(reshape);

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// TODO: Set ambient light
	set_AmbientLight(background);

	// Set initial material
	set_material(GL_FRONT_AND_BACK, &red_plastic);

	// Create menus
	glutCreateMenu(main_menu);
	glutAddMenuEntry("Brass",BRASS);
	glutAddMenuEntry("Red Plastic",RED_PLASTIC);
	glutAttachMenu(GLUT_RIGHT_BUTTON);

	// Load shader programs
	shaderProg = load_shaders(vertexFile,fragmentFile);

	// Activate shader program
	glUseProgram(shaderProg);

	// Associate num_lights parameter
	num_lights_param = glGetUniformLocation(shaderProg,"num_lights");

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Set number of lights
	glUniform1i(num_lights_param,num_lights);

	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set modelview matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// Set Global lights
	// TODO: Turn on light0 (broad spot)
	set_SpotLight(GL_LIGHT0, &white_light, light0_pos, light0_dir, light0_cutoff, light0_exp);

	// TODO: Turn on light1 (narrow spot)
	set_SpotLight(GL_LIGHT1, &blue_light, light1_pos, light1_dir, light1_cutoff, light1_exp);


	// Render cube using display list
	glPushMatrix();
		glRotatef(45.0f,1.0f,0.0f,0.0f);
		glRotatef(theta,0.0f,1.0f,0.0f);
		colorcube();
	glPopMatrix();
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// < > change subdivision level
	if (key == '<' || key == ',')
	{
		div_level--;
		if (div_level < 0)
		{
			div_level = 0;
		}
	}
	else if (key == '>' || key == '.')
	{
		div_level++;
	}

	// n changes normal mode
	if (key == 'n')
	{
		if (normal_mode == SURFACE)
		{
			normal_mode = VERTEX;
		}
		else if (normal_mode == VERTEX)
		{
			normal_mode = SURFACE;
		}
	}

	// <space> toggles animation
	if (key == ' ')
	{
		anim = !anim;
	}	
	
	// <esc> quits
	if (key == 27)
	{
		exit(0);
	}

	// Redraw screen
	glutPostRedisplay();
}

// Idle callback
void idlefunc()
{
	if (anim)
	{
		// Update rotation angle
		theta += dtheta;
		if (theta > 360.0f)
		{
			theta -= 360.0f;
		}
	
		glutPostRedisplay();
	}
}

// Reshape callback
void reshape(int w, int h)
{
	GLfloat ratio;

	// Set new screen extents
	glViewport(0,0,w,h);

	// Set projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	// Taller than wide so scale height
	if (w <= h)
	{
		ratio = (GLfloat) h / (GLfloat) w;
		glOrtho(-2.0f,2.0f,-2.0f*ratio,2.0f*ratio,-2.0f,2.0f);
	}
	// Wider than tall so scale width
	else
	{
		ratio = (GLfloat) w / (GLfloat) h;
		glOrtho(-2.0f*ratio,2.0*ratio,-2.0f,2.0f,-2.0f,2.0f);
	}
}

// Routine to draw cube
void colorcube()
{
	// Top face
	div_quad(cube[4], cube[7], cube[6], cube[5], vnorm[4], vnorm[7], vnorm[6], vnorm[5], div_level);

	// Bottom face
	div_quad(cube[0], cube[1], cube[2], cube[3], vnorm[0], vnorm[1], vnorm[2], vnorm[3], div_level);

	// Left face
	div_quad(cube[0], cube[3], cube[7], cube[4], vnorm[0], vnorm[3], vnorm[7], vnorm[4], div_level);

	// Right face
	div_quad(cube[1], cube[5], cube[6], cube[2], vnorm[1], vnorm[5], vnorm[6], vnorm[2], div_level);

	// Front face
	div_quad(cube[2], cube[6], cube[7], cube[3], vnorm[2], vnorm[6], vnorm[7], vnorm[3], div_level);

	// Back face
	div_quad(cube[0], cube[4], cube[5], cube[1], vnorm[0], vnorm[4], vnorm[5], vnorm[1], div_level);
}

// Routine to perform recursive subdivision
void div_quad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[], GLfloat n1[], GLfloat n2[], GLfloat n3[], GLfloat n4[], int n)
{
	GLfloat v1_prime[3],v2_prime[3],v3_prime[3],v4_prime[3],v5_prime[3];
	GLfloat n1_prime[3], n2_prime[3], n3_prime[3], n4_prime[3], n5_prime[3];

	// Recurse until n = 0
	if (n > 0)
	{
		// TODO: Compute midpoints
		for (int i = 0; i<3; i++)
		{
			v1_prime[i] = (v4[i] + v1[i]) / 2.0f;
			v2_prime[i] = (v1[i] + v2[i]) / 2.0f;
			v3_prime[i] = (v2[i] + v3[i]) / 2.0f;
			v4_prime[i] = (v3[i] + v4[i]) / 2.0f;
			v5_prime[i] = (v1[i] + v2[i] + v3[i] + v4[i]) / 4.0f;
			n1_prime[i] = (n4[i] + n1[i]) / 2.0f;
			n2_prime[i] = (n1[i] + n2[i]) / 2.0f;
			n3_prime[i] = (n2[i] + n3[i]) / 2.0f;
			n4_prime[i] = (n3[i] + n4[i]) / 2.0f;
			n5_prime[i] = (n1[i] + n2[i] + n3[i] + n4[i]) / 4.0f;
		}

		// TODO: Subdivide polygon
		div_quad(v1, v2_prime, v5_prime, v1_prime, n1, n2_prime, n5_prime, n1_prime, n - 1);
		div_quad(v2_prime, v2, v3_prime, v5_prime, n2_prime, n2, n3_prime, n5_prime, n - 1);
		div_quad(v1_prime, v5_prime, v4_prime, v4, n1_prime, n5_prime, n4_prime, n4, n - 1);
		div_quad(v5_prime, v3_prime, v3, v4_prime, n5_prime, n3_prime, n3, n4_prime, n - 1);
	}
	else
	{
		// TODO: Otherwise render quad
		rquad(v1, v2, v3, v4, n1, n2, n3, n4);
	}
}

// Routine to draw quadrilateral face
void rquad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[], GLfloat n1[], GLfloat n2[], GLfloat n3[], GLfloat n4[])
{
	GLfloat normal[3];

	// Draw face 
	glBegin(GL_POLYGON);
		// Surface normal
		if (normal_mode == SURFACE)
		{
			// TODO: Compute surface normal
			cross(v1, v2, v4, normal);
			normalize(normal);

			glNormal3fv(normal);
			glVertex3fv(v1);
			glVertex3fv(v2);
			glVertex3fv(v3);
			glVertex3fv(v4);
		}
		// Vertex normal
		else
		{
			// TODO: Set vertex normals
			glNormal3fv(n1);
			glVertex3fv(v1);
			glNormal3fv(n2);
			glVertex3fv(v2);
			glNormal3fv(n3);
			glVertex3fv(v3);
			glNormal3fv(n4);
			glVertex3fv(v4);
		}
	glEnd();
}

// Routine to process material menu selection
void main_menu(int id)
{
	// Set material to brass
	if (id == BRASS)
	{
		set_material(GL_FRONT_AND_BACK, &brass);
	}
	else if (id == RED_PLASTIC)
	{
		set_material(GL_FRONT_AND_BACK, &red_plastic);
	}
	glutPostRedisplay();
}

