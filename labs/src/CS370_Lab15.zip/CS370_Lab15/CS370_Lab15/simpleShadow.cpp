// CS370 - Fall 2014
// Lab15 - SimpleShadow

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "lighting.h"
#include "materials.h"

// Shader file utility functions
#include "shaderutils.h"

// Shader files
GLchar* lightVertexFile = "lightvert.vs";
GLchar* lightFragmentFile = "lightfrag.fs";
GLchar* defaultVertexFile = "basicvert.vs";
GLchar* defaultFragmentFile = "basicfrag.fs";

// Shader objects
GLuint lightProg;
GLuint defaultProg;
GLuint num_lights_param;

// Global light variables
GLint num_lights = 1;

#define BRASS 1
#define RED_PLASTIC 2

#define ICOSAHEDRON 1
#define CUBE 2
#define LIGHT_STEP 0.1f
#define ANG_STEP 1.0f

// Light position
GLfloat light0_pos[] = {0.0f,6.0f,0.0f,0.0f};

// Global object properties
GLfloat icos_color[] = {1.0f,0.0f,0.0f};
GLfloat icos_pos[] = {0.0f,2.0f,0.0f};
GLfloat icos_theta[] = {45.0f,-45.0f,0.0f};
GLfloat cube_color[] = {0.0f,1.0f,0.0f};
GLfloat cube_pos[] = {-1.5f,1.5f,1.5f};
GLfloat cube_theta[] = {45.0f,-45.0f,0.0f};
GLfloat cube_ang = 0.0f;
GLfloat shadow_color[] = {0.2f,0.2f,0.2f};
GLfloat table_color[] = {0.2f,0.2f,0.8f};
GLint obj = 0;

// Shadow matrix
GLfloat M_s[16];

// Mouse positions
GLint startx, starty;

// Global animation variables
GLint time = 0;
GLint lasttime = 0;
GLint fps = 30;

void display();
void render_Scene(bool shadow);
void keyfunc(unsigned char key, int x, int y);
void reshape(int w, int h);
GLuint load_shaders(GLchar* vertexFile, GLchar* shaderFile);
void mousefunc(int button, int state, int x, int y);
void mousemove(int x, int y);
void idlefunc();

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	// Set the window size to image size
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Simple Shadows");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// Define callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutReshapeFunc(reshape);
	glutMouseFunc(mousefunc);
	glutMotionFunc(mousemove);
	glutIdleFunc(idlefunc);

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Set shading model
	glShadeModel(GL_SMOOTH);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// TODO: Initialize shadow matrix

	// Set ambient light
	set_AmbientLight(background);

	// Load shader programs
	lightProg = load_shaders(lightVertexFile,lightFragmentFile);
	defaultProg = load_shaders(defaultVertexFile,defaultFragmentFile);

	// Associate num_lights parameter
	num_lights_param = glGetUniformLocation(lightProg,"num_lights");

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set modelview matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(1.0,1.0,1.0,0.0,0.0,0.0,0.0,1.0,0.0);

	// Render scene without shadows
	render_Scene(false);

	glPushMatrix();
		// TODO: Set shadow matrix

		// TODO: Render shadows

	glPopMatrix();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene(bool shadow)
{
	// Turn on global light0 (point)
	set_PointLight(GL_LIGHT0, &white_light, light0_pos);

	// Draw table (no shadow)
	if (!shadow)
	{
		glPushMatrix();
			glUseProgram(defaultProg);
			glColor3fv(table_color);
			glBegin(GL_POLYGON);
				glVertex3f(4.0f,-0.05f,4.0f);
				glVertex3f(4.0f,-0.05f,-4.0f);
				glVertex3f(-4.0f,-0.05f,-4.0f);
				glVertex3f(-4.0f,-0.05f,4.0f);
			glEnd();
		glPopMatrix();
	}

	// Draw icosahedron
	glPushMatrix();
		// TODO: Draw Icosahedron

		// Normal
		if (!shadow)
		{
			// TODO: Draw brass icosahedron
			glUseProgram(lightProg);
			glUniform1i(num_lights_param, num_lights);

		}
		// Shadow
		else
		{
			// TODO: Draw icosahedron shadow
			glUseProgram(defaultProg);

		}
	glPopMatrix();

	// Draw cube
	glPushMatrix();
		// TODO: Draw cube

		// Normal
		if (!shadow)
		{
			// TODO: Draw red plastic cube
			glUseProgram(lightProg);
			glUniform1i(num_lights_param, num_lights);

		}
		// Shadow
		else
		{
			// TODO: Draw cube shadow
			glUseProgram(defaultProg);

		}
	glPopMatrix();
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// w s moves light in z
	if (key == 'w' || key == 'W')
	{
		light0_pos[2] -= LIGHT_STEP;
	}
	else if (key == 's' || key == 'S')
	{
		light0_pos[2] += LIGHT_STEP;
	}

	// a d moves light in x
	if (key == 'a' || key == 'A')
	{
		light0_pos[0] -= LIGHT_STEP;
	}
	else if (key == 'd' || key == 'D')
	{
		light0_pos[0] += LIGHT_STEP;
	}

	// <esc> quits
	if (key == 27)
	{
		exit(0);
	}

	// Redraw screen
	glutPostRedisplay();
}

// Reshape callback
void reshape(int w, int h)
{
	GLfloat ratio;

	// Set new screen extents
	glViewport(0,0,w,h);

	// Set 3D projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	// Taller than wide so scale height
	if (w <= h)
	{
		ratio = (GLfloat) h / (GLfloat) w;
		glOrtho(-5.0f,5.0f,-5.0f*ratio,5.0f*ratio,-5.0f,5.0f);
	}
	// Wider than tall so scale width
	else
	{
		ratio = (GLfloat) w / (GLfloat) h;
		glOrtho(-5.0f*ratio,5.0*ratio,-5.0f,5.0f,-5.0f,5.0f);
	}
}

// Mouse callback
void mousefunc(int button, int state, int x, int y)
{
	// Rotate icosahedron on left click
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		obj = ICOSAHEDRON;
	}

	// Rotate cube on right click
	if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		obj = CUBE;
	}

	startx = x;
	starty = y;
}

// Mouse move function
void mousemove(int x, int y)
{
	// Adjust x and y icosahedron rotation angles
	if (obj == ICOSAHEDRON)
	{
		icos_theta[0] += (y - starty);
		icos_theta[1] += (x - startx);
	}

	// Adjust x and y cube rotation angles
	if (obj == CUBE)
	{
		cube_theta[0] += (y - starty);
		cube_theta[1] += (x - startx);
	}

	// Update mouse ref position
	startx = x;
	starty = y;

	// Render scene
	glutPostRedisplay();
}

// Idle callback
void idlefunc()
{

	time = glutGet(GLUT_ELAPSED_TIME);
	
	// Update if past desired interval
	if (time-lasttime > 1000.0f/fps)
	{
	
		// Revolve cube around icosahedron
		cube_ang += ANG_STEP;
		if (cube_ang > 360.0f)
		{
			cube_ang -= 360.0f;
		}

		// Update lasttime (reset timer)
		lasttime = time;

		// Render scene
		glutPostRedisplay();
	}
}
