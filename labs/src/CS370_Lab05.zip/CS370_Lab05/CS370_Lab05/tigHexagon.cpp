// CS370 - Fall 2014
// Lab05 - TIGHexagon

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glut.h>
#endif

// Hexagon vertices
GLfloat v[6][2] = {{-0.7188f,0.7706f},{-0.8438f,0.5541f},{-0.625f,0.2835f},
                   {-0.2812f,0.2294f},{-0.1562f,0.4459f},{-0.375f,0.7165f}};

// TODO: Unit hexagon vertices
GLfloat u[6][2];

// TODO: User defined transformation
GLfloat M[16];

void display();
void render_Scene();

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);

	// Set the window size to 500x500 pixels
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Translated Hexagon");

	// Define callbacks
	glutDisplayFunc(display);

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT);

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// Reset modelview matrix
	glLoadIdentity();

	// TODO: Draw red v hexagon vertices

	// Set transformations
	// TODO: Translate hexagon (in x and y)

	// TODO: Redraw green v hexagon (transformed)

	// TODO: Create instance transformation

	// TODO: Draw blue unit u hexagon

}
