// Sampler variables
uniform sampler2D colorMap;
uniform sampler2D normalMap;

// TODO: Varying light and viewer variables

void main()
{
	// TODO: Normalized light vector
  
	// Sample texture and normal map
	vec4 texColor = texture2D(colorMap, gl_TexCoord[0].st);
	vec4 bump = texture2D(normalMap, gl_TexCoord[0].st);

	// TODO: Unpack normal vector

	// TODO: Compute diffuse component

	// TODO: Blend lighting with texture

}
