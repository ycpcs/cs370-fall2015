// CS370 - Fall 2014
// Lab22 - BumpBall

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <SOIL/SOIL.h>

// Shader file utility functions
#include "shaderutils.h"
#include "lighting.h"

// Multitexture sphere source code
#include "sphere.h"

// Shader files
GLchar* bumpVertexFile = "bumpvert.vs";
GLchar* bumpFragmentFile = "bumpfrag.fs";
GLchar* texVertexFile = "texvert.vs";
GLchar* texFragmentFile = "texfrag.fs";

// Texture globals
#define NO_TEXTURES 2
#define BALL_UNIT 0
#define NORMAL_UNIT 1
#define BALL 0
#define NORMAL 1
GLuint tex_ids[NO_TEXTURES];
char texture_files[NO_TEXTURES][20] = {"Basketball.bmp","dimple_normal.bmp"};

// Shader objects
GLuint bumpProg;
GLuint texProg;
GLint bumpSampler[NO_TEXTURES];
GLint texSampler;

// TODO: Global tangent parameter

// Scene globals
GLfloat light0_pos[] = {2.0f,2.0f,2.0f,1.0f};
GLfloat light0_dir[] = {-1.0f,-1.0f,-1.0f};
GLfloat theta[] = {30.0f,45.0f,0.0f};
int startx = 0;
int starty = 0;
bool use_bump = false;

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void reshape(int w, int h);
void mousefunc(int button, int state, int x, int y);
void mousemove(int x, int y);
bool load_textures();

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	// Set the window size to image size
	glutInitWindowSize(512,512);

	// Create window
	glutCreateWindow("Bump Basketball");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// Define callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutReshapeFunc(reshape);
	glutMouseFunc(mousefunc);
	glutMotionFunc(mousemove);

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Set shading model
	glShadeModel(GL_SMOOTH);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// Enable lighting
	set_AmbientLight(background);
	set_SpotLight(GL_LIGHT0, &white_light,light0_pos,light0_dir,90.0f,0.0f);

	// Load textures
	if (!load_textures())
	{
		printf("Failed to load textures!\n");
		exit(0);
	}

	// Load shader programs
	bumpProg = load_shaders(bumpVertexFile, bumpFragmentFile);
	texProg = load_shaders(texVertexFile, texFragmentFile);

	// Associate shader sampler variables
	bumpSampler[BALL_UNIT] = glGetUniformLocation(bumpProg,"colorMap");
	bumpSampler[NORMAL_UNIT] = glGetUniformLocation(bumpProg,"normalMap");
	texSampler = glGetUniformLocation(texProg,"texMap");

	// TODO: Associate tangent shader variable

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set modelview matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glRotatef(theta[0],1.0f,0.0f,0.0f);
	glRotatef(theta[1],0.0f,1.0f,0.0f);

	// Render scene without shadows
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	if (use_bump)
	{
		// Activate bump map shader
		glUseProgram(bumpProg);
			
		// Associate BALL with texture unit 0
		glUniform1i(bumpSampler[BALL_UNIT],BALL);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D,tex_ids[BALL]);

		// Associate NORMAL with texture unit 1
		glUniform1i(bumpSampler[NORMAL],NORMAL);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D,tex_ids[NORMAL]);
	}
	else
	{
		// Activate standard texture shader
		glUseProgram(texProg);
				
		// Associate BALL with texture unit 0
		glUniform1i(texSampler,BALL);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D,tex_ids[BALL]);
	}

	// Draw bump mapped sphere
	glPushMatrix();
		mySphere2(use_bump, tangParam);
	glPopMatrix();
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// <space> toggles bump mapping
	if (key == ' ')
	{
		use_bump = !use_bump;
	}
	// <esc> quits
	if (key == 27)
	{
		exit(0);
	}

	// Redraw screen
	glutPostRedisplay();
}

// Reshape callback
void reshape(int w, int h)
{
	GLfloat ratio;

	// Set new screen extents
	glViewport(0,0,w,h);

	// Set 3D projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	// Taller than wide so scale height
	if (w <= h)
	{
		ratio = (GLfloat) h / (GLfloat) w;
		glOrtho(-2.0f,2.0f,-2.0f*ratio,2.0f*ratio,-2.0f,2.0f);
	}
	// Wider than tall so scale width
	else
	{
		ratio = (GLfloat) w / (GLfloat) h;
		glOrtho(-2.0f*ratio,2.0*ratio,-2.0f,2.0f,-2.0f,2.0f);
	}
}

// Mouse callback
void mousefunc(int button, int state, int x, int y)
{
	// Rotate about x and y axes for left button
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		startx = x;
		starty = y;
	}
}

// Mouse move callback
void mousemove(int x, int y)
{
	// Adjust x rotation angle
	theta[0] += (y - starty);
	if (theta[0] > 360.0)
	{
		theta[0] -= 360.0f;
	}
	else if (theta[0] < 0.0f)
	{
		theta[0] += 360.0f;
	}

	// Adjust y rotation angle
	theta[1] += (x - startx);
	if (theta[1] > 360.0)
	{
		theta[1] -= 360.0f;
	}
	else if (theta[1] < 0.0f)
	{
		theta[1] += 360.0f;
	}

	// Update mouse position
	startx = x;
	starty = y;

	// Redraw display
	glutPostRedisplay();
}

// Routine to load textures using SOIL
bool load_textures()
{
	// Load object textures normally
	for (int i=0; i < NO_TEXTURES; i++)
	{
		// Load bitmaps
		tex_ids[i] = SOIL_load_OGL_texture(texture_files[i],SOIL_LOAD_AUTO,SOIL_CREATE_NEW_ID,SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y);


		// Set texture properties if successfully loaded
		if (tex_ids[i] != 0)
		{
			// Set scaling filters
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST);

			// Set wrapping modes
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
		}
		// Otherwise texture failed to load
		else
		{
			return false;
		}
	}
	return true;
}

