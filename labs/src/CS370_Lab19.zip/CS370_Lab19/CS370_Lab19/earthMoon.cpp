// CS370 - Fall 2014
// Lab19 - EarthMoon

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <SOIL/SOIL.h>

// Shader file utility functions
#include "shaderutils.h"

// Shader files
GLchar* texVertexFile = "texturevert.vs";
GLchar* texFragmentFile = "texturefrag.fs";

// Shader objects
GLuint textureProg;
GLuint num_lights_param;
GLint texSampler;

// Texture constants
#define NO_TEXTURES 3
#define SPACE 0
#define EARTH 1
#define MOON 2

// Texture indices
GLuint tex_ids[NO_TEXTURES];

// Texture files
char texture_files[3][20] = {"space.jpg","et.bmp","mn.bmp"};

// Object quadrics
GLUquadricObj* earth;
GLUquadricObj* moon;

// Global rotation angles
GLfloat earth_theta = 0.0f;
GLfloat earth_rpm = 20.0f;
GLfloat moon_theta = 0.0f;
GLfloat moon_rpm = 5.0f;
GLfloat moon_rev = 5.0f;
GLfloat moon_ang = 0.0f;
GLfloat moon_dist = 5.0f;
bool animate = false;

// Animation variables
GLint fps = 25;
GLint time = 0;
GLint lasttime = 0;

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void idlefunc();
void reshape(int w, int h);
bool load_textures();

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	// Set the window size to image size
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Earth & Moon");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// Define callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutReshapeFunc(reshape);
	glutIdleFunc(idlefunc);

	// Set background color to black (...outer space!)
	glClearColor(0.0f,0.0f,0.0f,0.0f);

	// Set shading model
	glShadeModel(GL_SMOOTH);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// TODO: Create earth quadric with texture coords
	earth = gluNewQuadric();
	gluQuadricDrawStyle(earth,GLU_FILL);

	// TODO: Create moon quadric with texture coords
	moon = gluNewQuadric();
	gluQuadricDrawStyle(moon,GLU_FILL);

	// Load textures
	if (!load_textures())
	{
		exit(0);
	}

	// Load shader programs
	textureProg = load_shaders(texVertexFile,texFragmentFile);

	// Activate shader program
	glUseProgram(textureProg);

	// TODO: Associate and assign sampler parameter

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set modelview matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// Draw textured quad
	glPushMatrix();
		// TODO: Bind space texture

		// TODO: Draw space background with texture coordinates
		glBegin(GL_POLYGON);
			glVertex3f(-6.0f,-6.0f,-6.0f);
			glVertex3f(6.0f,-6.0f,-6.0f);
			glVertex3f(6.0f,6.0f,-6.0f);
			glVertex3f(-6.0f,6.0f,-6.0f);
		glEnd();
	glPopMatrix();

	// Draw textured earth
	glPushMatrix();
		// TODO: Bind earth texture

		// Render earth
		glRotatef(earth_theta,0.0f,1.0f,0.0f);
		glRotatef(-90.0f,1.0f,0.0f,0.0f);
		gluSphere(earth,2.0,50,50);
	glPopMatrix();

	// Draw textured moon
	glPushMatrix();
		// TODO: Bind moon texture

		// Render moon
		glRotatef(moon_ang,0.0f,1.0f,0.0f);
		glTranslatef(moon_dist,0.0f,0.0f);
		glRotatef(moon_theta,0.0f,1.0f,0.0f);
		glRotatef(-90.0f,1.0f,0.0f,0.0f);
		gluSphere(moon,1.0,50,50);
	glPopMatrix();
}

// Routine to load textures using SOIL
bool load_textures()
{
	for (int i=0; i < NO_TEXTURES; i++)
	{
		// TODO: Load images


		// Set texture properties if successfully loaded
		if (tex_ids[i] != 0)
		{
			// TODO: Set scaling filters

			// TODO: Set wrapping modes
		}
		// Otherwise texture failed to load
		else
		{
			return false;
		}
	}
	return true;
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// <space> to animate
	if (key == ' ')
	{
		animate = !animate;
		lasttime = glutGet(GLUT_ELAPSED_TIME);
	}

	// <esc> quits
	if (key == 27)
	{
		exit(0);
	}

	// Render scene
	glutPostRedisplay();
}

// Idle callback
void idlefunc()
{
	if (animate)
	{
		// Get total elapsed time
		time = glutGet(GLUT_ELAPSED_TIME);

		// Update if past desired interval
		if (time-lasttime > 1000.0f/fps)
		{
			// Spin earth about its axis
			earth_theta += 6.0f*earth_rpm*(time-lasttime)/1000.0f;
			if (earth_theta > 360.0f)
			{
				earth_theta -= 360.0f;
			}
		
			// Spin moon about its axis
			moon_theta += 6.0f*moon_rpm*(time-lasttime)/1000.0f;
			if (moon_theta > 360.0f)
			{
				moon_theta -= 360.0f;
			}
		
			// Orbit moon around earth
			moon_ang += 6.0f*moon_rev*(time-lasttime)/1000.0f;
			if (moon_ang > 360.0f)
			{
				moon_ang -= 360.0f;
			}
		
			// Update lasttime (reset timer)
			lasttime = time;

			// Render scene
			glutPostRedisplay();
		}
	}
}

// Reshape callback
void reshape(int w, int h)
{
	GLfloat ratio;

	// Set new screen extents
	glViewport(0,0,w,h);

	// Set 3D projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	// Taller than wide so scale height
	if (w <= h)
	{
		ratio = (GLfloat) h / (GLfloat) w;
		glOrtho(-7.0f,7.0f,-7.0f*ratio,7.0f*ratio,-7.0f,7.0f);
	}
	// Wider than tall so scale width
	else
	{
		ratio = (GLfloat) w / (GLfloat) h;
		glOrtho(-7.0f*ratio,7.0*ratio,-7.0f,7.0f,-7.0f,7.0f);
	}
}
