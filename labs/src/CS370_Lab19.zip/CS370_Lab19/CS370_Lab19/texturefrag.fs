/* Texture map fragment shader */

// TODO: Sampler variable

void main()
{
	// TODO: Sample texture

	// TODO: Apply texture map using replacement

}