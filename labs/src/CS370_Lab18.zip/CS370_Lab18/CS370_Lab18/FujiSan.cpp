// CS370 - Fall 2014
// Lab18 - Choppin' Sword

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <SOIL/SOIL.h>
#include "lighting.h"
#include "materials.h"

// Shader file utility functions
#include "shaderutils.h"

// Shader files
GLchar* vertexFile = "lightvert.vs";
GLchar* fragmentFile = "lightfrag.fs";

// Shader objects
GLuint shaderProg;
GLuint num_lights_param;

#define SPIN_STEP 0.2f
#define LIGHT_STEP 0.2f
#define SWORD 1

// Light0 (directional) Parameters
GLfloat light0_pos[] = {0.0f,2.0f,2.0f,1.0f};
GLfloat light0_dir[] = {0.0f,0.0f,-1.0f,0.0f};

// Global object initial positions
GLfloat sphere_pos[3] = {0.0f,0.0f,-0.2f};
GLfloat torus_pos[3] = {0.0f,-1.25f,1.5f};

// Global quadric
GLUquadricObj *quadric;

// Global animation variables
bool chop = false;
bool spin = false;
GLfloat light_theta = 0.0f;
bool rot_light = false;
int dir = 1;
GLfloat spin_theta = 0.0f;
GLfloat chop_theta = 0.0f;
GLfloat chop_step = 0.2f;
GLint num_lights = 1;
GLint ww;
GLint hh;

// TODO: Image parameters

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void idlefunc();
void reshape(int w, int h);
void create_lists();
unsigned char* load_image(GLchar* imageFile);
void draw_background(unsigned char* image);

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	// TODO: Load image before creating window

	// TODO: Set the window size to match image resolution
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Fuji");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// Define callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutIdleFunc(idlefunc);
	glutReshapeFunc(reshape);

	// Set background color to black
	glClearColor(0.0f,0.0f,0.0f,0.0f);

	// Set shading model
	glShadeModel(GL_SMOOTH);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// Enable lighting
	glEnable(GL_LIGHTING);

	// Turn on light0
	set_PointLight(GL_LIGHT0,&white_light,light0_pos);
	//set_DirectionalLight(GL_LIGHT0,&white_light,light0_dir);
	
	// Set ambient light
	set_AmbientLight(background);

	// Enable alpha blending
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

	// Create quadric
	quadric = gluNewQuadric();
	gluQuadricDrawStyle(quadric,GLU_FILL);
	gluQuadricNormals(quadric,GLU_SMOOTH);

	// Load shader programs
	shaderProg = load_shaders(vertexFile,fragmentFile);

	// Activate shader program
	glUseProgram(shaderProg);

	// Associate num_lights parameter
	num_lights_param = glGetUniformLocation(shaderProg,"num_lights");

	// Create display lists
	create_lists();

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Set number of lights
	glUniform1i(num_lights_param,num_lights);

	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// TODO: Draw background

	// TODO: Reset projection matrix

	// Reset modelview matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(0.0f,0.0f,4.0f,0.0f,0.0f,0.0f,0.0f,1.0f,0.0f);

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// Rotate light
	glPushMatrix();
	glRotatef(light_theta, 0.0f, 1.0f, 0.0f);
	set_PointLight(GL_LIGHT0, &white_light, light0_pos);
	glPopMatrix();

	// Draw sword
	glPushMatrix();
		glRotatef(spin_theta,0.0,1.0,0.0);
		glRotatef(chop_theta,1.0,0.0,0.0);
		glScalef(1.5f,1.5f,1.5f);
		glCallList(SWORD);
	glPopMatrix();
}

// Image loading function
unsigned char* load_image(GLchar* imageFile)
{
	unsigned char* imgptr;

	// TODO: Load image using SOIL

	return imgptr;
}

// Routine to draw background image
void draw_background(unsigned char* image)
{
	// TODO: Disable blending, and depth test for background image

	// TODO: Set 2D projection for image

	// TODO: Draw image (inverting)

	// TODO: Reset zoom factors

	// TODO: Reenable lighting, blending, and depth test

}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// <space> toggles light rotation
	if (key == ' ')
	{
		rot_light = !rot_light;
	}

	// c toggles chop
	if (key == 'c' || key == 'c')
	{
		chop = !chop;
	}

	// s toggles spin
	if (key == 's' || key == 's')
	{
		spin = !spin;
	}

	// + - changes background light
	if (key == '=' || key == '+')
	{
		for(int i=0; i<3; i++)
		{
			background[i] += 0.1f;
			if (background[i] > 1.0f)
			{
				background[i] = 1.0f;
			}
		}
		set_AmbientLight(background);
	}
	else if (key == '-' || key == '_')
	{
		for(int i=0; i<3; i++)
		{
			background[i] -= 0.1f;
			if (background[i] < 0.0f)
			{
				background[i] = 0.0f;
			}
		}
		set_AmbientLight(background);
	}


	// <esc> quits
	if (key == 27)
	{
		exit(0);
	}

	// Redraw screen
	glutPostRedisplay();
}

// Idle callback
void idlefunc()
{
	// Chop
	if (chop)
	{
		chop_theta += dir*chop_step;
		if (chop_theta > 30.0f)
		{
			chop_theta = 29.9f;
			chop_step = chop_step*3.0f;
			dir = -1;
		}
		else if (chop_theta < -30.0f)
		{
			chop_theta = -29.9f;
			chop_step = chop_step/3.0f;
			dir = 1;
		}
	}

	// Spin
	if (spin)
	{
		spin_theta += SPIN_STEP;
		if (spin_theta > 360.0f)
		{
			spin_theta -= 360.0f;
		}
	}

	// Rotate light
	if (rot_light)
	{
		light_theta += LIGHT_STEP;
		if (light_theta > 360.0f)
		{
			light_theta -= 360.0f;
		}
	}

	// Update scene if necessary
	if (chop || spin || rot_light)
	{
		glutPostRedisplay();
	}
}

// Reshape callback
void reshape(int w, int h)
{
	// Set new screen extents
	glViewport(0,0,w,h);

	ww = w;
	hh = h;

	// TODO: Move to display()
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	// Taller than wide so scale height
	GLfloat ratio;
	if (ww <= hh)
	{
		ratio = (GLfloat) hh / (GLfloat) ww;
		glFrustum(-4.0f,4.0f,-4.0f*ratio,4.0f*ratio,2.0f,6.0f);
	}
	// Wider than tall so scale width
	else
	{
		ratio = (GLfloat) ww / (GLfloat) hh;
		glFrustum(-4.0f*ratio,4.0*ratio,-4.0f,4.0f,2.0f,6.0f);
	}
}

void create_lists()
{
	glNewList(SWORD,GL_COMPILE);
		glPushAttrib(GL_CURRENT_BIT);
		// Handle
		glPushMatrix();
			set_material(GL_FRONT_AND_BACK,&silver);
			gluCylinder(quadric,0.1,0.1,0.6,20,20);
		glPopMatrix();
		// Guard
		glPushMatrix();
			set_material(GL_FRONT_AND_BACK,&brass);
			gluDisk(quadric,0.0,0.4,20,20);
		glPopMatrix();
		// Blade
		glPushMatrix();
			set_material(GL_FRONT_AND_BACK,&silver);
			glRotatef(180.0f,1.0f,0.0f,0.0f);
			gluCylinder(quadric,0.05,0.0,2.5,20,20);
		glPopMatrix();
		glPopAttrib();
	glEndList();
}