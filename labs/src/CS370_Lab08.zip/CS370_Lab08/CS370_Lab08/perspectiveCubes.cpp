// CS370 - Fall 2014
// Lab08 - PerspectiveCubes

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Shader file utility functions
#include "shaderutils.h"

// Shader files
GLchar* vertexFile = "basicvert.vs";
GLchar* fragmentFile = "basicfrag.fs";

// Shader objects
GLuint shaderProg;

#define DEG2RAD 0.01745
#define X 0
#define Y 1
#define Z 2
#define ORTHOGRAPHIC 1
#define PERSPECTIVE 2
#define CUBE 1

// Cube vertices
GLfloat cube[][3] = {{-1.0f,-1.0f,-1.0f},{1.0f,-1.0f,-1.0f},{1.0f,-1.0f,1.0f},
                     {-1.0f,-1.0f,1.0f},{-1.0f,1.0f,-1.0f},{1.0f,1.0f,-1.0f},
                     {1.0f,1.0f,1.0f},{-1.0f,1.0f,1.0f}};

// Vertex colors
GLfloat colors[][3] = {{0.0f,0.0f,0.0f},{1.0f,0.0f,0.0f},{1.0f,0.0f,1.0f},
                       {0.0f,0.0f,1.0f},{0.0f,1.0f,0.0f},{1.0f,1.0f,0.0f},
                       {1.0f,1.0f,1.0f},{0.0f,1.0f,1.0f}};

// Global spherical coord values
GLfloat azimuth = 45.0f;
GLfloat daz = 2.0f;
GLfloat elevation = 45.0f;
GLfloat del = 2.0f;
GLfloat radius = 6.0f;
GLfloat dr = 0.1f;
GLfloat min_radius = 2.0f;

// Global camera vectors
GLfloat eye[3] = {4.344f,3.152f,2.682f};
GLfloat at[3] = {0.0f,0.0f,0.0f};
GLfloat up[3] = {0.0f,1.0f,0.0f};

// Global projection flag
int proj = ORTHOGRAPHIC;

// Animation flag
GLint anim = false;

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void reshape(int w, int h);
void colorcube();
void quad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[],
	      GLfloat c1[], GLfloat c2[], GLfloat c3[], GLfloat c4[]);
void create_lists();

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	// Set the window size to 500x500 pixels
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Projection Stack");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// Define callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutReshapeFunc(reshape);

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	// TODO: Create display list

	// Load shader programs
	shaderProg = load_shaders(vertexFile,fragmentFile);

	// Activate shader program
	glUseProgram(shaderProg);

	// TODO: Compute initial cartesian camera position
	
	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	// TODO: Set orthographic projection
	if (proj == ORTHOGRAPHIC)
	{

	}
	// TODO: Set perspective projection
	else if (proj == PERSPECTIVE)
	{

	}

	// TODO: Set modelview matrix

	// TODO: Set camera position

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// TODO: Render cube using display list

	// TODO: Render sphere using glut object

}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// TODO: Toggle projection mode
	if (key == 'o')
	{

	}
	else if (key == 'p')
	{

	}

	// TODO: Adjust azimuth angle
	if (key == 'a')
	{

	}
	else if (key == 'd')
	{

	}

	// TODO: Adjust elevation angle
	if (key == 'w')
	{

	}
	else if (key == 's')
	{

	}

	// TODO: Adjust radius (zoom)
	if (key == 'x')
	{

	}
	else if (key == 'z')
	{

	}

	// TODO: Compute cartesian camera position

	// <esc> quits
	if (key == 27)
	{
		exit(0);
	}

	// Redraw screen
	glutPostRedisplay();
}

// Routine to create display lists
void create_lists()
{
	// TODO: Create colorcube display list

}

// Reshape callback
void reshape(int w, int h)
{
	// Set new screen extents
	glViewport(0,0,w,h);
}

// Routine to draw cube
void colorcube()
{
	// Top face
	quad(cube[4],cube[7],cube[6],cube[5],colors[0],colors[0],colors[0],colors[0]);

	// Bottom face
	quad(cube[0],cube[1],cube[2],cube[3],colors[1],colors[1],colors[1],colors[1]);

	// Left face
	quad(cube[0],cube[3],cube[7],cube[4],colors[2],colors[2],colors[2],colors[2]);

	// Right face
	quad(cube[1],cube[5],cube[6],cube[2],colors[3],colors[3],colors[3],colors[3]);

	// Front face
	quad(cube[2],cube[6],cube[7],cube[3],colors[4],colors[4],colors[4],colors[4]);

	// Back face
	quad(cube[0],cube[4],cube[5],cube[1],colors[5],colors[5],colors[5],colors[5]);
}

// Routine to draw (outlined) quadrilateral face
void quad(GLfloat v1[], GLfloat v2[], GLfloat v3[], GLfloat v4[],
	      GLfloat c1[], GLfloat c2[], GLfloat c3[], GLfloat c4[])
{
	// Draw face
	glBegin(GL_POLYGON);
		glColor3fv(c1);
		glVertex3fv(v1);
		glColor3fv(c2);
		glVertex3fv(v2);
		glColor3fv(c3);
		glVertex3fv(v3);
		glColor3fv(c4);
		glVertex3fv(v4);
	glEnd();

	// Draw outline
	glColor3f(0.0f,0.0f,0.0f);
	glBegin(GL_LINE_LOOP);
		glVertex3fv(v1);
		glVertex3fv(v2);
		glVertex3fv(v3);
		glVertex3fv(v4);
	glEnd();
}
