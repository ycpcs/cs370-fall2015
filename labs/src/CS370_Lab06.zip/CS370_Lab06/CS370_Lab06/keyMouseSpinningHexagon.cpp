// CS370 - Fall 2014
// Lab06 - KeyMouseSpinningHexagon

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <stdio.h>
#include <stdlib.h>

// Shader file utility functions
#include "shaderutils.h"

// Shader files
GLchar* vertexFile = "basicvert.vs";
GLchar* fragmentFile = "basicfrag.fs";

// Shader objects
GLuint shaderProg;

// Unit hexagon vertices
GLfloat u[6][2] = {{0.5f,0.866f},{-0.5f,0.866f},{-1.0f,0.0f},
                   {-0.5f,-0.866f},{0.5f,-0.866f},{1.0f,0.0f}};

// Global scale factors
GLfloat scale = 0.5f;
GLfloat dscale = 0.05f;
GLfloat min_scale = 0.1f;
GLfloat max_scale = 1.0f;

// Global rotation value
GLfloat theta = 0.0f;
GLfloat dtheta = 0.1f;

// Global translation values
GLfloat hex_x = 0.0f;
GLfloat hex_y = 0.0f;

// TODO: Global mouse position values

// Conversion from screen to world coordinates
GLfloat dt = 0.005f;

// TODO: Animation flag

void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void mousefunc(int button, int state, int x, int y);
void movefunc(int x, int y);
void idlefunc();

int main(int argc, char *argv[])
{
	// Initialize GLUT
	glutInit(&argc,argv);

	// Initialize the window with double buffering and RGB colors
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);

	// Set the window size to 500x500 pixels
	glutInitWindowSize(500,500);

	// Create window
	glutCreateWindow("Spinning Hexagon");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// TODO: Define callbacks
	glutDisplayFunc(display);

	// Set background color to white
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Load shader programs
	shaderProg = load_shaders(vertexFile,fragmentFile);

	// Activate shader program
	glUseProgram(shaderProg);

	// Begin event loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT);

	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{
	// Set transformations
	glLoadIdentity();
	glTranslatef(hex_x,hex_y,0.0f);
	glRotatef(theta,0.0f,0.0f,1.0f);
	glScalef(scale,scale,1);

	// Draw red hexagon
	glColor3f(1.0f,0.0f,0.0f);
	glBegin(GL_POLYGON);
	for(int i=0; i<6; i++)
	{
		glVertex2fv(u[i]);
	}
	glEnd();
}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// TODO: < (or ,) shrinks object
	if (key == '<' || key == ',')
	{

	}
	// TODO: > (or .) enlarges object
	else if (key == '>' || key == '.')
	{

	}
	// TODO: <space> toggles animation
	else if (key == ' ')
	{

	}
	// TODO: <esc> quits
	else if (key == 27)
	{

	}

	// TODO: Redraw screen

}

// Mouse click callback
void mousefunc(int button, int state, int x, int y)
{
	// TODO: Store cursor position when left button is clicked

}

// Mouse move callback
void movefunc(int x, int y)
{
	GLint dx, dy;

	// TODO: Compute change in cursor position (inverted y)

	// TODO: Update hexagon (bounded) position

	// TODO: Reset start position

	// TODO: Redraw screen

}

// Idle callback
void idlefunc()
{
	// TODO: Animation code

		// Redraw screen (only if animating)

}

