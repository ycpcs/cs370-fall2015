// CS370 - Fall 2014
// Lab01 - HelloOpenGL

#ifdef OSX
    #include <GLUT/glut.h>
#else
    #include <GL/glut.h>
#endif

void display();
void render_Scene();
